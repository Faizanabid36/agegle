@extends('website_layouts.main')

@section('content')

<div class="row">
    <div class="col-xs-12 col-md-3 ">
      
    </div>

    <div class="col-xs-12 col-md-6 ">
      
  

<div class="card shadow2">
<h4>Contact Us</h4>
  <p  >Please Contact via emal cs@agegle.com
  </p>
</div>

    </div>
    <div class="col-xs-12 col-md-3 ">
       
    </div>
</div>
@endsection