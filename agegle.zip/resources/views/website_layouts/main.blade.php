@include('website_layouts.header')
@yield('content')
@include('website_layouts.footer')


