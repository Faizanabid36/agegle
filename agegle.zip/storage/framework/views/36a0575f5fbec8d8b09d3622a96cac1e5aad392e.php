<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="mb-5">
                    <h3 class="float-left">Pages</h3>
                    <div class="float-right" style="width:40%">
                        <form action="">
                            <input class="rounded-lg" style="width: 80%" name="search"
                                   placeholder="Search By Profile Name">
                            <button type="submit" class="btn btn-sm btn-primary"> Search</button>
                        </form>
                    </div>
                </div>
                <?php if(session('success')): ?>
                    <div class="alert alert-success" role="alert">
                        <?php echo e(session('success')); ?>

                    </div>
                <?php endif; ?>
                <div class="mt-5">
                    <table class="table table-secondary">
                        <thead class="thead-dark">
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Title</th>
                            <th scope="col">Link to Profile</th>
                            <th scope="col">Status</th>
                            <th scope="col">Preview</th>
                            <th scope="col">Action</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row"><?php echo e($loop->iteration); ?></th>
                                <td><?php echo e($image->profile->name); ?></td>
                                <td>
                                    <a href="<?php echo e(route('view',$image->profile->slug)); ?>"><?php echo e(route('view',$image->profile->slug)); ?></a>
                                </td>
                                <td><?php echo e($image->profile->is_approved?'Approved':'Pending Approval'); ?></td>
                                <td><img src="<?php echo e($image->attachment_url); ?>" width="100" alt=""></td>
                                <td class="d-flex">
                                    <button class="btn btn-success ml-3">
                                        <a class="text-white"
                                           href="<?php echo e(route('admin.approve.image',$image->id)); ?>">Approve</a>
                                    </button>
                                    <button class="btn btn-danger ml-3">
                                        <a class="text-white"
                                           href="<?php echo e(route('admin.decline',$image->id)); ?>"
                                           onclick="return confirm('Are you sure?')">Reject</a>
                                    </button>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\htdocs\agegle\resources\views/pages/approve.blade.php ENDPATH**/ ?>