<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <h3><?php echo e('Add Sponsor to Profile '.$profile->name); ?></h3>
            <div class="col-md-10">
                <?php if(session('success')): ?>
                    <div class="alert alert-success" role="alert">
                        <?php echo e(session('success')); ?>

                    </div>
                <?php endif; ?>
                <div class="mb-5">
                    <h3 class="float-left">New Ad</h3>
                </div>
                <div class="mt-5">
                    <div class="card">
                        <div class="card-header">
                            <h1>Add Sponsor ad to Profile: <u><?php echo e($profile->name); ?></u></h1>
                        </div>
                        <div class="card-body">
                            <form method="post" enctype="multipart/form-data"
                                  action="<?php echo e(route('admin.store_sponsor',$profile->id)); ?>">
                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <label for="ad_title">Sponsor title</label>
                                    <input name="ad_title" required type="text"
                                           class="form-control"
                                           id="ad_title" placeholder="Enter title">
                                </div>
                                <div class="form-group">
                                    <label for="ad_url">Sponsor URL</label>
                                    <input name="ad_url" required type="text"
                                           class="form-control"
                                           id="ad_url" placeholder="Enter URL">
                                </div>
                                <div class="form-group">
                                    <label for="icon">Choose Image</label>
                                    <input type="file" class="form-control" name="pic" id="icon"
                                           placeholder="Choose File">
                                </div>
                                <button type="submit" class="btn btn-primary">Save</button>
                            </form>

                        </div>
                    </div>
                </div>
            </div>
        </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\htdocs\agegle\resources\views/pages/add_sponsor.blade.php ENDPATH**/ ?>