<style>
    .footer {
        height: 14vh;
        position: fixed;
        left: 0;
        bottom: 0;
        width: 100%;
        background-color: white;
        color: white;
        text-align: center;
    }
</style>

<footer class="footer">
    <div style="padding: 0px 0px 0px 0px">
        <div class="container">
            <div class="row">
                <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-xs-3 col-md-3 col-md-3">
                        <div class="fa-container">
                            <img width="40" src="<?php echo e(asset($page->page_icon)); ?>">
                        </div>
                        <a href="<?php echo e(url($page->slug)); ?>" style="text-decoration: none">
                            <p style="font-size: 16px;color: black" class="text-center txt txt1">
                                <?php echo e($page->title); ?>

                            </p>
                        </a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</footer>
<script>
    const ASSET = "<?php echo e(asset('')); ?>"
        function revertIcon(e) {
            let id = e.id
            document.getElementById(id).src = ASSET + 'website/assets/images/arrow.svg'
        }

    function activeIcon(e) {
        let id = e.id
        document.getElementById(id).src = ASSET + 'website/assets/images/blue.jpg'
        document.getElementById(id).style.cursor = 'pointer'
    }

    $(document).ready(function () {
        let page = 2;
        $('#see_more').click(function () {
            $.ajax({
                type: 'GET',
                url: "?page=" + page,
                success: function (data) {
                    page += 1;
                    if (data.html == 0) {
                        alert('No More Data Display')
                    } else {
                        $('#content').append($(data.html))
                    }
                }, error: function (data) {
                    console.log(data)
                },
            })
        })
        $('#submit_form_button').click(function (e) {
            e.preventDefault()
            $('#submit_form').submit()
        })
    })
</script>
<?php /**PATH E:\htdocs\agegle\resources\views/website_layouts/footer.blade.php ENDPATH**/ ?>