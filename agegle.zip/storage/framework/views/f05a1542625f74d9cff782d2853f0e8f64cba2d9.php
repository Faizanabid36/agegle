











<footer class="footer">
    <div style="padding: 21px 0px">
        <div class="container">
            <div class="row">
                <div class="col-xs-3 col-md-3 col-md-3">
                    <div class="fa-container">
                        <i class="fa fa-globe fa-2x" aria-hidden="true"></i>
                    </div>
                    <a href="<?php echo e(route('home_page')); ?>" style="text-decoration: none"><h3 class="text-center txt txt1 ">
                            Home
                        </h3>
                    </a>
                </div>

                <div class="col-xs-3 col-md-3 col-md-3">
                    <div class="fa-container">
                        <i class="fa fa-heart-o fa-2x" aria-hidden="true"></i>
                    </div>
                    <a href="<?php echo e(route('create')); ?>" style="text-decoration: none"><h3 class="text-center txt txt1">Create
                            Name</h3></a>

                </div>
                <div class="col-xs-3 col-md-3 col-md-3">
                    <div class="fa-container">
                        <i class="fa fa-bell-o fa-2x" aria-hidden="true"></i>
                    </div>
                    <a href="<?php echo e(route('about')); ?>" style="text-decoration: none"><h3 class="text-center txt txt1">About
                            Us</h3></a>

                </div>
                <div class="col-xs-3 col-md-3 col-md-3">
                    <div class="fa-container">
                        <i class="fa fa-envelope-o fa-2x" aria-hidden="true"></i>
                    </div>
                    <a href="<?php echo e(route('contact')); ?>" style="text-decoration: none"><h3 class="text-center txt txt1">
                            Contact</h3>
                    </a>
                </div>
                <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-xs-3 col-md-3 col-md-3">
                        <div class="fa-container">
                            <img width="50" src="<?php echo e(asset($page->page_icon)); ?>">
                        </div>
                        <a href="<?php echo e(route('contact')); ?>" style="text-decoration: none">
                            <h3 class="text-center txt txt1">
                                <?php echo e($page->title); ?>

                            </h3>
                        </a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</footer>
<script>
    $(document).ready(function () {
        let page = 2;
        $('#see_more').click(function () {
            $.ajax({
                type: 'GET',
                url: "?page=" + page,
                success: function (data) {
                    page += 1;
                    if (data.html == 0) {
                        alert('No More Data Display')
                    } else {
                        $('#content').append($(data.html))
                    }
                }, error: function (data) {
                    console.log(data)
                },
            })
        })
        $('#submit_form_button').click(function (e) {
            e.preventDefault()
            $('#submit_form').submit()
        })
    })
</script>
<?php /**PATH E:\htdocs\agegle\resources\views/website_layouts/footer.blade.php ENDPATH**/ ?>