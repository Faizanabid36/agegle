<?php $__env->startSection('content'); ?>
    <body>
    <div class="section-container">
        <div class="container">
            <div class="row" id="content">
                <?php if($profile->is_sponsored): ?>
                    <div class="col-xs-4 col-md-3">
                        <a href="<?php echo e($profile->sponsor_ad->ad_url); ?>">
                            <img style="height: 170px;width: 240px;"
                                 src="<?php echo e($profile->sponsor_ad->ad_attachment); ?>" alt=""
                                 class="img-responsive">
                        </a>
                        <div style="margin-left: 10px;">
                            <h4 class="txt" style="color: black;margin: 10px 0px 0px 0px">Sponsor Ad</h4>
                            <p><?php echo e($profile->sponsor_ad->ad_title); ?></p>
                        </div>
                    </div>
                <?php endif; ?>
                <?php $__currentLoopData = $profile_extras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $profile_extra): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-xs-4 col-md-3">
                        <img style="height: 170px;width: 240px;" src="<?php echo e($profile_extra->attachment_url); ?>"
                             class="img-responsive">

                        <div style="margin-left: 10px; margin-right: 10px">
                            <?php if($profile_extra->attachment_url==asset('icons/unavailable.jpg')): ?>
                                <img onmouseover="activeIcon(this)" onmouseout="revertIcon(this)"
                                     src="<?php echo e(asset('website/assets/images/arrow.svg')); ?>" name="pic"
                                     id="<?php echo e($profile_extra->id); ?>" class="picture"
                                     height="20px" width="20px" style="float: right">
                                <form id="add_image-<?php echo e($profile_extra->id); ?>" enctype="multipart/form-data"
                                      action="<?php echo e(route('add_image',[$profile->slug,$profile_extra->id])); ?>"
                                      method="POST">
                                    <?php echo csrf_field(); ?>
                                    <input class="fileinput" id="fileinput-<?php echo e($profile_extra->id); ?>" type="file"
                                           name="fileinput" style="display:none"
                                           style="visibility: hidden;"/>
                                </form>
                            <?php endif; ?>
                            <h4 class="txt" style="color: black;margin: 10px 0px 0px 0px"><?php echo e($profile->name); ?></h4>
                            <p>Age <?php echo e($profile_extra->age); ?> <?php echo e(($profile_extra->age +(int)$profile->started_year)); ?></p>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="row">
                <div class="col-xs-12 col-md-12 col-md-12">
                    <h3 class="text-center txt txt1 " id="see_more">See More</h3>
                </div>
            </div>
        </div>
    </div>
    </body>
    <script type="text/JavaScript"
            src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.1/jquery.min.js">
    </script>

    <script>
        $(function () {
            $('.picture').on('click', function () {
                $(`#fileinput-${this.id}`).trigger('click');
                let id = this.id;
                $(`#fileinput-${id}`).change(function (e) {
                    $(`#add_image-${id}`).submit()
                })
            });
        });
        function inp(e)
        {
            $(`#fileinput-${e.id}`).trigger('click');
            let id = e.id;
            $(`#fileinput-${id}`).change(function (e) {
                $(`#add_image-${id}`).submit()
            })
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('website_layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\htdocs\agegle\resources\views/website/view.blade.php ENDPATH**/ ?>