<?php $__env->startSection('content'); ?>
    <body>
    <div class="section-container">
        <div class="container">
            <?php if(count($pages)>0): ?>
                <div class="row" id="content">
                    <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-xs-4 col-md-3">
                            <a href="<?php echo e(route('view',$page->slug)); ?>">
                                <img src="<?php echo e($page->disp_img??$page->extra->first()->attachment_url); ?>" alt="<?php echo e($page->slug); ?>"
                                     class="img-responsive"></a>
                            <div style="margin-left: 10px;">
                                <h4 class="txt" style="color: black;margin: 10px 0 0 0"><?php echo e(ucfirst($page->name)); ?></h4>
                                <p><?php echo e($page->disp_age??$page->extra->count()); ?> of <?php echo e($page->extra->count()); ?> years</p>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="row">
                    <div class="col-xs-12 col-md-12 col-md-12">
                        <h3 class="text-center txt txt1 " id="see_more">See More</h3>
                    </div>
                </div>
            <?php else: ?>
                <div class="row">
                    <div class="col-xs-12 col-md-12 col-md-12">
                        <h2 class="text-center txt" style="color: red">Nothing More to Display</h2>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
    </body>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('website_layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\htdocs\agegle\resources\views/website/home.blade.php ENDPATH**/ ?>