<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="mb-5">
                    <h3 class="float-left">Pages</h3>
                    <div class="float-right" style="width:40%">
                        <form action="">
                            <input class="rounded-lg" style="width: 80%" name="search" placeholder="Search By Profile Name">
                            <button type="submit" class="btn btn-sm btn-primary"> Search</button>
                        </form>
                    </div>
                </div>
                <?php if(session('success')): ?>
                    <div class="alert alert-success" role="alert">
                        <?php echo e(session('success')); ?>

                    </div>
                <?php endif; ?>
                <div class="mt-5">
                    <table class="table table-secondary">
                        <thead class="thead-dark">
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Title</th>
                            <th scope="col">Link</th>
                            <th scope="col">Ad attached</th>
                            <th scope="col">Status</th>
                            <th scope="col">Action</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $profiles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $profile): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row"><?php echo e($loop->iteration); ?></th>
                                <td><?php echo e($profile->name); ?></td>
                                <td><a href="<?php echo e(route('view',$profile->slug)); ?>"><?php echo e(route('view',$profile->slug)); ?></a></td>
                                <td><?php echo e($profile->is_sponsored?'Yes':'No'); ?></td>
                                <td><?php echo e($profile->is_approved?'Approved':'Pending Approval'); ?></td>
                                <td class="d-flex">
                                    <?php if($profile->is_sponsored): ?>
                                        <button class="btn btn-success ml-3">
                                            <a class="text-white" href="<?php echo e(route('admin.remove_sponsor',$profile->id)); ?>">Remove
                                                Sponsor</a>
                                        </button>
                                    <?php else: ?>
                                        <button class="btn btn-success ml-3">
                                            <a class="text-white" href="<?php echo e(route('admin.add_sponsor',$profile->id)); ?>">Add
                                                Sponsor</a>
                                        </button>
                                    <?php endif; ?>
                                    <button class="btn btn-warning ml-3">
                                        <a href="<?php echo e(route('admin.profile.edit',$profile->id)); ?>">Edit</a>
                                    </button>
                                    <button class="btn btn-danger ml-3">
                                        <a class="text-white"
                                           onclick="return confirm('Are you sure?')"
                                           href="<?php echo e(route('admin.profile.delete',$profile->id)); ?>">Delete</a>
                                    </button>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\htdocs\agegle\resources\views/pages/profiles.blade.php ENDPATH**/ ?>