<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-10">
                <?php if(session('success')): ?>
                    <div class="alert alert-success" role="alert">
                        <?php echo e(session('success')); ?>

                    </div>
                <?php endif; ?>
                <?php if(session('errors')): ?>
                    <div class="alert alert-danger" role="alert">
                        <?php echo e(session('errors')->first()); ?>

                    </div>
                <?php endif; ?>
                <div class="mb-5">
                    <h3 class="float-left">Edit Profile</h3>
                </div>
                <div class="mt-5">
                    <div class="card">
                        <div class="card-header">
                            <h1>Edit Page</h1>
                        </div>
                        <div class="card-body">
                            <form method="post" enctype="multipart/form-data"
                                  action="<?php echo e(route('admin.profile.update',$profile->id)); ?>">
                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <label for="title">Profile Name</label>
                                    <input value="<?php echo e($profile->name); ?>" name="name" required
                                           type="text"
                                           class="form-control"
                                           id="title" placeholder="Enter title">
                                </div>
                                <button type="submit" class="btn btn-primary">Save</button>
                            </form>

                        </div>
                    </div>
                </div>
            </div>
        </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\htdocs\agegle\resources\views/pages/edit_profile.blade.php ENDPATH**/ ?>