

<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-xs-12 col-md-3 ">
      
    </div>

    <div class="col-xs-12 col-md-6 ">
      
  

<div class="card shadow2">
<h4>Contact Us</h4>
  <p  >Please Contact via emal cs@agegle.com
  </p>
</div>

    </div>
    <div class="col-xs-12 col-md-3 ">
       
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('website_layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\htdocs\agegle\resources\views/website/contact.blade.php ENDPATH**/ ?>